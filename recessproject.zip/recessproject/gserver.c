#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include<signal.h>
#include<assert.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<sys/time.h>
#include<sys/stat.h>
#include<sys/resource.h>
#include<netinet/in.h>
#include<pthread.h>
#include<arpa/inet.h>


#define PORT 4444
//#include<my_global.h>
//#include<mysql/mysql.h>

//Function to split string in a format similar to strtok()
char** Split(const char *str, char delimiter){
	int len, i, j;
	char* buf;
	char** ret;

	len = strlen(str);
	buf = malloc(len + 1);
	memcpy(buf, str, len + 1);

	j = 1;
	for (i = 0; i < len; ++i){
		if (buf[i] == delimiter){
			while (buf[i + 1] == delimiter) i++;
			j++;
		}
	}

	ret = malloc(sizeof(char*) * (j + 1));
	ret[j] = NULL;

	ret[0] = buf;
	j = 1;
	for (i = 0; i < len; ++i){
		if (buf[i] == delimiter){
			buf[i] = '\0';
			while (buf[i + 1] == delimiter) i++;
			ret[j++] = &buf[i + 1];
		}
	}
	return ret;
}



//Function to write to the Ready list text file
void Ready_list(char* String,int priority,int count){
	struct flock lock;// the lock structure
  int fd;

  lock.l_type = F_WRLCK;
  lock.l_whence = SEEK_SET;
  lock.l_start = 0;
  lock.l_len = 0;

	FILE *fptr;
	fptr = fopen("Ready_list.txt","a+");
	fd = open("Ready_list.txt", O_WRONLY | O_APPEND | O_CREAT, 0666);
	fcntl(fd, F_SETLKW, &lock);//Locking the Ready_list file while current fork write to it

	fprintf(fptr, "%s %d %d\n",String,priority,count);

	fclose(fptr);
	close(fd);//Closing the file lock
}

//Structure for carrying the busylist
struct Busy_list{
	char ClientID[100];//Client IP address and Port number
	char JOB[100];//The Job itself
	int characters;//Number of characters in the job
	int No_jobs;//Number of jobs by from this partiular client
	int IsReplace;//Replace job or not?
	int Priority;//Priority of the job
};

//Function to evaluate the priorities
void PriorityEvaluator(){
	struct flock lock;
  int fd;

  lock.l_type = F_WRLCK;
  lock.l_whence = SEEK_SET;
  lock.l_start = 0;
  lock.l_len = 0;

	struct Busy_list Array[100];

  char line[256];
	int size;
	FILE *Ufptr;
	Ufptr = fopen("Unsorted_busy_list.txt","r+");

	for(size=0;fgets(line,sizeof(line),Ufptr);size++){

		char** Parts;
		Parts = Split(line,'\t');
		strcpy(Array[size].ClientID,*(Parts+0));
		strcpy(Array[size].JOB,*(Parts+1));
		Array[size].characters = atoi(Parts[2]);
		Array[size].No_jobs = atoi(Parts[3]);
		Array[size].IsReplace = atoi(Parts[4]);
		Array[size].Priority = atoi(Parts[4]);
	}
	fd = open("Unsorted_busy_list.txt", O_WRONLY | O_APPEND | O_CREAT, 0666);

	fcntl(fd, F_SETLKW, &lock);
 	remove("Unsorted_busy_list.txt");

	fclose(Ufptr);
	close(fd);

	//Getting client with the most number of jobs
	int max_jobs;
  max_jobs = Array[0].No_jobs;
  for (int i = 1; i < size; i++){
		if (max_jobs < Array[i].No_jobs)
			{	max_jobs = Array[i].No_jobs;	}
	}
	//Getting job with least number of characters
	int min_xters;
	min_xters = Array[0].characters;
  for (int i = 1; i < size; i++){
		if (min_xters > Array[i].characters)
			{	min_xters = Array[i].characters;	}
	}
	//Summing up the priorities
	for (int i = 0; i < size; i++){
		if(Array[i].characters == min_xters){
			Array[i].Priority += 1;
		}
		if(Array[i].No_jobs == max_jobs){
			Array[i].Priority += 2;
		}
	}

	//Rearranging the structure
	for(int i=0; i < size ;i++){
		for(int j=0; j < size ;j++){
			if(Array[i].Priority < Array[j].Priority){
				char swap1[100];
				strcpy(swap1,Array[i].ClientID);
				strcpy(Array[i].ClientID,Array[j].ClientID);
				strcpy(Array[j].ClientID,swap1);
				char swap2[100];
				strcpy(swap2,Array[i].JOB);
				strcpy(Array[i].JOB,Array[j].JOB);
				strcpy(Array[j].JOB,swap2);
				int a,b;
				a = Array[i].Priority;
				Array[i].Priority = Array[j].Priority;
				Array[j].Priority = a;
			}
		}
	}
	/*Printing the Busy list.We shall also print out the number of jobs sent by a
	particular client for calculations of success and failure rate by the admin page*/
	for(int i=0; i < size ;i++){

		FILE *Bfptr;
		Bfptr = fopen("Busy_list.txt","a");
		fprintf(Bfptr,"%s\t%s\t%d\t\n",Array[i].ClientID,Array[i].JOB,Array[i].Priority);
		fclose(Bfptr);//closing the busy list file
	}
	bzero(Array,sizeof(Array));
}

double span;//This is used for the duration of a job

int main(int argc, char *argv[]){
	system("clear");

	struct flock lock;
  int fd,fdb;

  lock.l_type = F_WRLCK;
  lock.l_whence = SEEK_SET;
  lock.l_start = 0;
  lock.l_len = 0;

	//Starting the server
	
	int sockfd,ret;
	struct sockaddr_in serverAddr;

	int client_socket;
	struct sockaddr_in ClientAddr;
	int	addr_size = sizeof(ClientAddr);

	char Job[1024];//Carries string received from the client
	char String[1024];//
	pid_t childpid;//The child fork

	sockfd = socket(AF_INET,SOCK_STREAM,0);
	if(sockfd<0){
		printf("[*]Error in connection.\n");
		exit(1);
	}
	printf("[*]server socket created successfully.\n");

	memset(&serverAddr,'\0',sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(PORT);
	serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	ret = bind(sockfd,(struct sockaddr*)&serverAddr,sizeof(serverAddr));
	if(ret<0){
		printf("[+]Error in binding.\n");
		exit(1);
	}else{
		printf("[+]Bind to prort %d\n",4444);
	}

	if(listen(sockfd,10)==0){
		printf("[+]Listening....\n");
	}else{
		printf("[+]Error in bind.\n");
	}


	while(1){

		client_socket = accept(sockfd, (struct sockaddr*)&ClientAddr, (socklen_t*)&addr_size);
		if(client_socket<0){
			exit(1);
		}else{
			printf("\nClient %s:%d connected\n",inet_ntoa(ClientAddr.sin_addr),ntohs(ClientAddr.sin_port));
		}

		if((childpid = fork())==0){
			close(sockfd);

			while(1){
				pid_t STATUSpid;

				recv(client_socket,Job,1024,0);

				time_t t = time(NULL);
				struct tm tm = *localtime(&t);

				printf(":::: %s:%d request: %s\n",inet_ntoa(ClientAddr.sin_addr),ntohs(ClientAddr.sin_port),Job);

				char Owner[20];//Will be used while reading jobs from the Busy_list
				sprintf(Owner,"%s:%d",inet_ntoa(ClientAddr.sin_addr),ntohs(ClientAddr.sin_port));

				//The check status child fork
				STATUSpid = fork();
				if(STATUSpid == 0){
					while(1){
						char status[8];
						recv(client_socket,status,1024,0);
						printf(" %s:%d busy-time-request: %s\n",inet_ntoa(ClientAddr.sin_addr),ntohs(ClientAddr.sin_port),status);

						int	No_of_jobs_left = 1;

						while((strcasecmp(status,"STATUS")) != 0){
							send(client_socket, &No_of_jobs_left, sizeof(No_of_jobs_left), 0);

							char WaitMessage[1024] = "Please wait...";
							send(client_socket, &WaitMessage, sizeof(WaitMessage), 0);
							recv(client_socket,status,1024,0);
							printf(" %s:%d busy-time-request: %s\n",inet_ntoa(ClientAddr.sin_addr),ntohs(ClientAddr.sin_port),status);
						}

						struct Pending{
							char JOB[60];//The Job itself
							int Priority;//Priority of the job
							float Left_time;//Estimated time left
						}PendingJOB_[100];

						//Status check code
						char sline[256];
						FILE *Sfptr;
						Sfptr = fopen("Busy_list.txt","r");

						char PendingJobClientID[20];

						for(int i=0; fgets(sline,sizeof(sline),Sfptr); i++){

							char** Parts;
							Parts = Split(sline,'\t');

							strcpy(PendingJobClientID,*(Parts+0));
							if(strcmp(PendingJobClientID,Owner) == 0){

								No_of_jobs_left++;
								int	remainingjobs_positions = ++i;

								strcpy(PendingJOB_[i].JOB,*(Parts+1));
								PendingJOB_[i].Priority = atoi(Parts[2]);
								PendingJOB_[i].Left_time = (span * remainingjobs_positions);//Span was a globally declared variable
							}
						}
						No_of_jobs_left--;
						send(client_socket, &No_of_jobs_left, sizeof(No_of_jobs_left), 0);

						for (int i = 0; i < No_of_jobs_left; i++){
							char StatusResult[1024];

							sprintf(StatusResult,"%s\t%d\t%f",PendingJOB_[i].JOB,PendingJOB_[i].Priority,PendingJOB_[i].Left_time);
							send(client_socket, &StatusResult, sizeof(StatusResult), 0);
							
							FILE *fs;
							
							fs = fopen("status.txt","w");
							fprintf(fs, "%s,",Owner);
							fprintf(fs, "%s",PendingJOB_[i].JOB);
							fprintf(fs, "%d",PendingJOB_[i].Priority);
							fprintf(fs, "%f",PendingJOB_[i].Left_time);
							fclose(fs);


							//char Q[2048];
							//sprintf(Q,"INSERT INTO Status(ClientID,Job,Priority,Time_left) VALUES('%s','%s',%d,%f)",Owner,PendingJOB_[i].JOB,PendingJOB_[i].Priority,PendingJOB_[i].Left_time);
							//tables(Q);
						}
					}
				}//End of status check

				int count = 1;

 				if(strcasecmp(Job,"EXIT")==0){//The exit comand from the client
					strcpy(String,"Your exit from the String Task Server is complete\n\n\tCONNECTION TERMINATED\n");
					send(client_socket, &count, sizeof(count), 0);
					send(client_socket, &String, sizeof(String), 0);
					close(client_socket);
					break;
				}else{

					for(int l=0;Job[l] != '\0';l++){
					if(Job[l] == ';')
							{	count++;  }
					}
					send(client_socket, &count, sizeof(count), 0);

					char** job = Split(Job,';');

					for(int f = 0; f < count; f++){

						char** _SplitJob;
						char ReplaceOnot[20];
						_SplitJob = Split(job[f],' ');
						strcpy(ReplaceOnot,*(_SplitJob));
						strcpy(String,*(_SplitJob + 1));

						int xters = 0;
						for(int l=0;String[l] != '\0';l++){
							xters++;
							if(xters > 99){
								String[l] = '\0';
								xters = 99;
								String[l++] = '\0';
							}
						}

						int Replace_o_not;
						if(strcasecmp(ReplaceOnot,"REPLACE")== 0){
							Replace_o_not = 3;
						}else{	Replace_o_not = 0;	}

						FILE *Ufptr;
						Ufptr = fopen("Unsorted_busy_list.txt","a+");
						fd = open("Unsorted_busy_list.txt", O_WRONLY | O_APPEND | O_CREAT, 0666);
						fcntl(fd, F_SETLKW, &lock);

						fprintf(Ufptr, "%s:%d\t%s\t%d\t%d\t%d\n",inet_ntoa(ClientAddr.sin_addr),ntohs(ClientAddr.sin_port),job[f],xters,count,Replace_o_not);

						close(fd);
						fclose(Ufptr);
					}

					PriorityEvaluator();

					for(int f=0; f < count; f++){

						char LostJob[20];

						char line[256];
						FILE *Bfptr;
						FILE *Cfptr;
						Bfptr = fopen("Busy_list.txt","r+");

						fgets(line,sizeof(line),Bfptr);
						char** Parts;
						Parts = Split(line,'\t');
						strcpy(LostJob,*(Parts+0));

						while(strcmp(LostJob,Owner) < 0){
							fgets(line,sizeof(line),Bfptr);
							Parts = Split(line,'\t');
							strcpy(LostJob,*(Parts+0));
						}

						//Removing the read line
						Cfptr = fopen("Copy.txt", "w+");

						for(int i=0 ;fgets(line, sizeof(line), Bfptr) != NULL; i++){
							fd = open("Copy.txt", O_WRONLY | O_APPEND | O_CREAT, 0666);
							fcntl(fd, F_SETLKW, &lock);

							fprintf(Cfptr, "%s", line);
						}
								//busylistfile
						fdb = open("Busy_list.txt", O_WRONLY | O_APPEND | O_CREAT, 0666);
						fcntl(fdb, F_SETLKW, &lock);
						fclose(Cfptr);
						remove("Busy_list.txt");
						fclose(Bfptr);
						rename( "Copy.txt", "Busy_list.txt" );
						close(fd);
						close(fdb);

						//The job operation
						strcpy(job[f],*(Parts+1));
						int priority = atoi(*(Parts+2));

						clock_t duration;
						duration = clock();

						int xters = 0;
						for(int l=0;String[l] != '\0';l++){
							xters++;
							if(xters > 99){
								String[l] = '\0';
								xters = 99;
							}
						}

						char task[20];
						char q[2048];
						char** SplitJob;

						SplitJob = Split(job[f],' ');
						strcpy(task,*(SplitJob));
						strcpy(String,*(SplitJob + 1));

						if(xters<=50){

							int Doublejob  = strcasecmp(task,"DOUBLE");
							int Reversejob = strcasecmp(task,"REVERSE");
							int Deletejob  = strcasecmp(task,"DELETE");
							int Replacejob = strcasecmp(task,"REPLACE");
							int Encryptjob = strcasecmp(task,"ENCRYPT");
							int Decryptjob = strcasecmp(task,"DECRYPT");

							if(Doublejob == 0){//double

								char Double[256];
								strcpy(Double,String);
								strcat(String,Double);
								strcpy(task,"Double");
							}else if(Reversejob == 0){//reverse

								int r = strlen(String) - 1;
								int v = 0;
								char ch;
   							while (r > v){
      						ch = String[r];
     						  String[r] = String[v];
     						  String[v] = ch;
     						  r--; v++;
				    		}
								strcpy(task,"Reverse");
							}else if(Deletejob == 0){//Delete

								char Str2Del[256];
								char DelTrend[256];

								strcpy(Str2Del,*(SplitJob + 1));
								strcpy(DelTrend,*(SplitJob + 2));

								char** DelTrendP;
								DelTrendP = Split(DelTrend,',');
								char *null = " ";

								for(int k=0;DelTrendP[k] != '\0';k++){

									int p = atoi(DelTrendP[k]);
									--p;
									*(Str2Del + p) = *null;
								}

								char* i = Str2Del;
 								char* j = Str2Del;
  							while(*j != 0){
				    			*i = *j++;
    							if(*i != ' ')
      							{	i++; }
  							}
  							*i = 0;
								strcpy(String,Str2Del);
								strcpy(task,"Delete");
							}else if(Replacejob == 0){//replace

								char Str2Rep[256];
								char RepTrend[256];

								strcpy(Str2Rep,*(SplitJob + 1));
								strcpy(RepTrend,*(SplitJob + 2));

								char** RepTrendP;
								RepTrendP = Split(RepTrend,',');

								for(int k=0;RepTrendP[k] != '\0';k++){

									char** tracer;
									tracer = Split(RepTrendP[k],'-');

									int p = atoi(tracer[0]);
									--p;

									char *rep = tracer[1];
									*(Str2Rep + p) = *rep;
								}
								strcpy(String,Str2Rep);
								strcpy(task,"Replace");
							}else if(Encryptjob == 0){//Encrpytion
								strcpy(String,"Encrypt");
								strcpy(task,"Encrypt");
							}else if(Encryptjob == 0){//Decryption
								strcpy(String,"Decrypt");
								strcpy(task,"Decrypt");
							}else{//Non of the above
								char error[256] = {"ERROR:Please enter a recognised command"};
								strcpy(String,error);
								strcpy(task,"ERROR");
							}

							duration = clock() - duration;
							double Duration = ((double)duration)/CLOCKS_PER_SEC;
							span = Duration;

								FILE *f; //log files here
								f = fopen("clientlogs.txt","a+");
								if( f == NULL){
									printf("No Logs \n");
								}
								//fprintf(f, "%s\n\t","Client Logs" );
								//fprintf(f, "%d\t,%s\t,%s,%d:%d:%d\t,%f\t,%f\n",clientid,Job,String, tm.tm_hour,tm.tm_min,tm.tm_sec,Duration );
							
							fprintf(f, "%d,",ntohs(ClientAddr.sin_port));
							fprintf(f, "%d:%d:%d,",tm.tm_mday,tm.tm_mon+1,tm.tm_year+1900);
							fprintf(f, "%d:%d:%d,", tm.tm_hour,tm.tm_min,tm.tm_sec);
							fprintf(f, "%s,",task );
							fprintf(f, "%s,",String );
							fprintf(f, "%f\n",span );
						
								fclose(f);
													//clientlogsfile
							//sprintf(q,"INSERT INTO Logs(ClientIP,ClientPort,Submission_date,Submission_time,Job_type,Duration_sec) VALUES('%s',%d,'%d-%d-%d','%d:%d:%d','%s',%f)",inet_ntoa(ClientAddr.sin_addr),ntohs(ClientAddr.sin_port),tm.tm_mday,tm.tm_mon+1,tm.tm_year+1900,tm.tm_hour,tm.tm_min,tm.tm_sec,task,span);
							int JobID;
							Ready_list(String,priority,count);
						}else{

							duration = clock() - duration;
							double Duration = ((double)duration)/CLOCKS_PER_SEC;
							span = Duration;

						/*	sprintf(q,"INSERT INTO Logs(ClientIP,ClientPort,Submission_date,Submission_time,Job_type,Duration_sec) VALUES('%s',%d,'%d-%d-%d','%d:%d:%d','%s',%f)",inet_ntoa(ClientAddr.sin_addr),ntohs(ClientAddr.sin_port),tm.tm_mday,tm.tm_mon+1,tm.tm_year+1900,tm.tm_hour,tm.tm_min,tm.tm_sec,task,span);
							int JobID = tables(q);

							sprintf(q,"INSERT INTO Black_list(JobID,Job_characters) VALUES(%d,%d)",JobID,xters);
							tables(q);
							strcpy(String,"---BLACKLISTED: Job contains more than 50 characters!!"); */
							int JobID;

							FILE *fb;
							
							fb = fopen("blacklist.txt","w");
							fprintf(fb, "%d,",JobID);
							fprintf(fb, "%s",xters);
							
							fclose(fb);





						}
						send(client_socket, &String, sizeof(String), 0);
					}
					bzero(String,sizeof(String));
					bzero(Job,sizeof(Job));
				}
				kill(STATUSpid,SIGKILL);
				bzero(Owner,sizeof(Owner));
			}
			printf("Client %s:%d disconnected\n\n",inet_ntoa(ClientAddr.sin_addr),ntohs(ClientAddr.sin_port));
		}
	}
	close(client_socket);
	return 0;
}