<?php
  session_start();
  if(!isset($_SESSION['logged_in'])){
  	header("Location:login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>HOMEPAGE:</title>
</head>
<body bgcolor="skyblue">
<center><u><a href="/var/www/html/homepage.html"><h1>LOGOUT</h1></a></u>
<button name="test" id="test" value="Click here">
</center>
</body>
</html>