#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 4444

int main(){
	char status[1024];
	int clientSocket, ret;
	struct sockaddr_in serverAddr;
	//char buffer[1024];
	char job[1024];
	int clientId;
	//char Job[1024];

	clientSocket = socket(AF_INET, SOCK_STREAM, 0);
	if(clientSocket < 0){
		printf("[-]Error in connection.\n");
		exit(1);
	}
	printf("[+]Client Socket is created.\n");

	memset(&serverAddr, '\0', sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(PORT);
	serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
//	while(1){
	ret = connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
	if(ret < 0){
		printf("[-]Error in connection.\n");
		exit(1);
	}
	printf("[+]Connected to Server.\n");


		/*int	No_of_jobs_left = 1;
		char WaitMessage[1024] = "Please wait...";
		printf("enter request:");
		scanf("%[^\n]s",&status[0]);
		send(clientSocket,status,1024,0);
		recv(clientSocket, &No_of_jobs_left, sizeof(No_of_jobs_left), 0);
		printf("%s\n",WaitMessage);*/


		printf("");
		scanf("%[^\n]s", &job[0]);
		send(clientSocket, job, sizeof(job), 0);


		
		char Result[1024];
		for ( int count = 0; count < Result; ++count)
			{
		if(recv(clientSocket, Result, 1024, 0) < 0){
			printf("[-]Error in receiving data.\n");
		}else{
			
			
				printf("Result: \t%s\n", Result);
			
			}
			
		}
		close(clientSocket);

	return 0;
}