<?php
$interval=5; //minutes
set_time_limit(0);
while (true)
{
$now=time();
include("test.php");
sleep($interval*05-(time()-$now));
}
?>