<?php

$con = mysql_connect("localhost","root","Chrispus 1");
     if(!$con){
           die("Database Connection failed".mysql_error());
}else{
$db_select = mysql_select_db("Data", $con);
     if(!$db_select){
           die("Database selection failed".mysql_error());
}else{

   }
}

$records = mysql_query("SELECT * FROM clients");

 

?>

<!-- This piece of PHP code defines the structure of the html table -->

 

<!DOCTYPE html>
<html>
    <head>
        <title> Fetching data </title>
    </head>

    <body>

        <table width="400" border="2" cellpadding="2" cellspacing='1'>

           <tr bgcolor="#2ECCFA">
                     <th> JobId</th>
                     <th>ClientId Title</th>
                     <th>Job</th>
                      <th>Result</th>
                       <th>Time</th>
                        <th>Duration</th>

           </tr>

<!-- We use while loop to fetch data and display rows of date on html table -->

<?php
echo "crispus";

     while ($clients = mysql_fetch_assoc($records)){

           echo "<tr>";
               echo "<td>".$clients['JobId']."</td>";
               echo "<td>".$clients['ClientId']."</td>";
               echo "<td>".$clients['Job']."</td>";
               echo "<td>".$clients['Result']."</td>";
               echo "<td>".$clients['Time']."</td>";
               echo "<td>".$clients['Duration']."</td>";
           echo "</tr>";

     }
?>
        </table>

   </body>

</html>
