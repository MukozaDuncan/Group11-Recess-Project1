
<?php

// run this code
$conn = new mysqli('localhost','root','Chrispus 1','Data');
$file = fopen("/home/cris/crispus/ready.txt", "r");
while (!feof($file)) {
	$content = fgets($file);
	$carray = explode(",",$content);
	list($ClientId,$Result) = $carray;
	var_dump($content);

	$sql = "INSERT INTO `ready`(`ClientId`,`Result`) VALUES ('$ClientId','$Result')";
	$conn->query($sql);


}

fclose($file);


?>