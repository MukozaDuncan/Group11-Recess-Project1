
<?php

// run this code
$conn = new mysqli('localhost','root','Chrispus 1','Data');
$file = fopen("/home/cris/crispus/clientlogs.txt", "r");
while (!feof($file)) {
	$content = fgets($file);
	$carray = explode(",",$content);
	list($ClientId,$Job,$Result) = $carray;
	var_dump($content);

	$sql = "INSERT INTO `logs`( `ClientId`, `Job`, `Result`) VALUES ('$ClientId','$Job','$Result')";
	$conn->query($sql);


}

fclose($file);


?>