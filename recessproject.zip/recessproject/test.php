	
<script>
setTimeout(function () { window.location.reload(); }, 10*60*1000);
 //just show current time stamp to see time of last refresh.
//document.write(new Date());
</script>

<?php
$conn = new mysqli('localhost','root','Chrispus 1','Data');
$file = fopen("/home/cris/crispus/clientlogs.txt","r");
while (!feof($file)) {
	$content = fgets($file);
	var_dump($content);
	$carray = explode(",",$content);
	list($ClientId,$job,$Result,$Time,$Duration) = $carray;
	$sql = "INSERT INTO `clients`(`ClientId`, `Job`, `Result`, `Time`, `Duration`) VALUES ('$ClientId','$job','$Result','$Time','$Duration')";
	$conn->query($sql);

	
}



fclose($file);

?>