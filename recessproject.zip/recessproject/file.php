






//$con = mysqli_connect("localhost","root","Chrispus 1","Data");
 //if (mysqli_connect_errno())
   //   {
     // echo "Failed to connect to MySQL: " . mysqli_connect_error();
      //}

$handle = fopen("/home/cris/crispus/clientlogs.txt", "r");
if ($handle) {
    while (($line = fgets($handle)) !== false) {

         $lineArr = explode(",", "$line");
        echo "<pre>";
         var_dump($lineArr); // to make sure array is ok

         // instead assigning one by onb use php list -> http://php.net/manual/en/function.list.php            
         list($clientId, $time, $task, $result) = $lineArr;

         // and then insert data
    //     mysqli_query($con,INSERT INTO `ready_jobs` (clientId, time, task, result)VALUES(" ('$clientId', '$time', '$task', '$result')");
    

    fclose($handle);
}



<?php
$handle = fopen("/home/cris/crispus/clientlogs.txt", "r");
if ($handle) {
    while (($line = fgets($handle)) !== false) {

         $lineArr = explode(",", "$line");
        echo "<pre>";
         var_dump($lineArr);
echo "no work done";
}
?>
