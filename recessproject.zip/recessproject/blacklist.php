<?php
$conn = new mysqli('localhost','root','Chrispus 1','Data');
$file = fopen("/home/cris/crispus/blacklist.txt","r");
while (!feof($file)) {
	$content = fgets($file);
	$carray = explode(",",$content);
	list($ClientId,$job,$Reason) = $carray;
	$sql = "INSERT INTO `blacklist`(`ClientId`, `Job`, `Reason`) VALUES ('$ClientId','$job','$Reason')";
	$conn->query($sql);
	
}
fclose($file);
?>